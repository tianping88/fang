<?php

return array(
		'LOGIN_SUCCESS'                =>"登录成功！",
		'PASSWORD_NOT_RIGHT'           =>"密码错误！",
		'PASSWORD_REQUIRED'            =>"密码不能为空！",
		'CAPTCHA_REQUIRED'             =>"验证码不能为空！",
		'CAPTCHA_NOT_RIGHT'            =>"验证码错误！",
		'USERNAME_NOT_EXIST'           =>"用户名不存在！",
		'USERNAME_OR_EMAIL_EMPTY'      =>"用户名或邮箱不能为空！",
		
		
);